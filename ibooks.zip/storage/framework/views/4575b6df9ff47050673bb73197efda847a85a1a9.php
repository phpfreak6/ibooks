<?php $__env->startSection('content'); ?>

    <div class="container">
        <p><a href="<?php echo e(url('/shop')); ?>">Shop</a> / <?php echo e($book->name); ?></p>
        <h1><?php echo e($book->name); ?></h1>

        <hr>

        <div class="row">
            <div class="col-md-4">
                <img src="<?php echo e(asset('img/' . $book->image)); ?>" alt="book" class="img-responsive">
            </div>

            <div class="col-md-8">
                <h3>$<?php echo e($book->price); ?></h3>
                <form action="<?php echo e(url('/cart')); ?>" method="POST" class="side-by-side">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id" value="<?php echo e($book->id); ?>">
                    <input type="hidden" name="name" value="<?php echo e($book->name); ?>">
                    <input type="hidden" name="price" value="<?php echo e($book->price); ?>">
                    <input type="submit" class="btn btn-success btn-lg" value="Add to Cart">
                </form>

                <form action="<?php echo e(url('/wishlist')); ?>" method="POST" class="side-by-side">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id" value="<?php echo e($book->id); ?>">
                    <input type="hidden" name="name" value="<?php echo e($book->name); ?>">
                    <input type="hidden" name="price" value="<?php echo e($book->price); ?>">
                    <input type="submit" class="btn btn-primary btn-lg" value="Add to Wishlist">
                </form>


                <br><br>

                <?php echo e($book->description); ?>

            </div> <!-- end col-md-8 -->
        </div> <!-- end row -->

        <div class="spacer"></div>

        <div class="row">
            <h3>You may also like...</h3>

            <?php $__currentLoopData = $interested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="thumbnail">
                        <div class="caption text-center">
                            <a href="<?php echo e(url('shop', [$book->slug])); ?>"><img src="<?php echo e(asset('img/' . $book->image)); ?>" alt="book" class="img-responsive"></a>
                            <a href="<?php echo e(url('shop', [$book->slug])); ?>"><h3><?php echo e($book->name); ?></h3>
                            <p><?php echo e($book->price); ?></p>
                            </a>
                        </div> <!-- end caption -->

                    </div> <!-- end thumbnail -->
                </div> <!-- end col-md-3 -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div> <!-- end row -->

        <div class="spacer"></div>


    </div> <!-- end container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>